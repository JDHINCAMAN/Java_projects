
package misClases;


public class Persona {
    
    public Persona(){}
    
    public void agregarProd(){
    
    }
    
    public void suscribirse(){
    
    }
    
    
    
}


