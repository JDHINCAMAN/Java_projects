
package misClases;


public class TrabajadorServicios extends Trabajador {
   
    
    public TrabajadorServicios(String nombre, String clave){
        super(nombre, clave);
    
    }
    
}
