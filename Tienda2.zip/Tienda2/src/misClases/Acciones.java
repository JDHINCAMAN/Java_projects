
package misClases;

public interface Acciones {
    
    public void comprar();
    public void alquilar();
    public void abonarCredito();
    public void solicitarCredito();
    
    
    
    
}
